function setup() {
  createCanvas(500, 500); // canvas width/height
  background(0); // Make background black
}

function draw(){
  // Start - draw a white ellipse
  fill(255)
  ellipse(250, 250, 200, 200); // x, y, w, h
}