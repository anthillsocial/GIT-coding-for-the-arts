# Template: p5.js

This is a template for a basic p5.js sketch. This is an *offline* sketch which will work without an internet connection. 

### ← README.md

The file where you can tell people what your project does, how you built it, and any other information. 

### ← index.html

You don't need to touch this, it's all set up for you to load the p5.js file and your sketch.js file. 

### ← sketch.js

This is where you should write your p5.js code.

### ← p5.js

The p5.js framwork. 


