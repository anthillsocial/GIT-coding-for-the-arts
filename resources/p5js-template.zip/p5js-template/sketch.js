//THIS IS A COMMENT!!! A template sketch for p5.js

//run once when our index.html file is first loaded
function setup() {
  createCanvas(500, 500); //width in pixels, height in pixels
}

//draw is run in a loop
function draw() {
  //draw a black background
  background(0);
  //set fill colour to white
  fill(255);
  //draw an ellipse
  ellipse(250, 250, 200, 200);
}
